package com.example.zakupy;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;


public class ItemInputDialog extends AppCompatDialogFragment {
    ItemsAdapter itemsAdapter;

    public ItemInputDialog(ItemsAdapter itemsAdapter ) {
        this.itemsAdapter = itemsAdapter;
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Dodaj produkt");

        final EditText input = new EditText(getActivity());
//        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        builder.setView(input);
        builder.setPositiveButton("Zapisz", (dialog, which) -> {
            String inputItem = input.getText().toString();
            itemsAdapter.add(new Item(inputItem));
        });
        return builder.create();
    }
}
