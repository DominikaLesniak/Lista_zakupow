package com.example.zakupy;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toSet;

public class MainActivity extends AppCompatActivity {
    private static final String LIST_PREFS_NAME = "ITEM_LIST";

    ListView listView;
    ArrayList<Item> items;
    ItemsAdapter itemsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setUpToolbar();
        loadList();

        listView = findViewById(R.id.listView);
        itemsAdapter = new ItemsAdapter(this, R.layout.item, items);
        listView.setAdapter(itemsAdapter);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);

        FloatingActionButton button = findViewById(R.id.floatingActionButton);
        button.setOnClickListener(v -> openDialog());
    }

    @Override
    protected void onPause() {
        saveList();
        super.onPause();
    }

    public void openDialog() {
        ItemInputDialog inputDialog = new ItemInputDialog(itemsAdapter);
        inputDialog.show(getSupportFragmentManager(), "in");
    }

    private void setUpToolbar() {
        Toolbar myToolbar = findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        ActionBar supportActionBar = getSupportActionBar();
        supportActionBar.setDisplayShowTitleEnabled(false);
    }

    void loadList() {
        SharedPreferences preferences = this.getPreferences(Context.MODE_PRIVATE);
        Set<String> itemSet = preferences.getStringSet(LIST_PREFS_NAME, new HashSet<>());
        items = deserializeItems(itemSet);
    }

    void saveList() {
        SharedPreferences preferences = this.getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = preferences.edit();

        Set<String> itemSet = serializeItems();
        editor.putStringSet(LIST_PREFS_NAME, itemSet);
        editor.apply();
    }

    private Set<String> serializeItems() {
        return items.stream()
                .map(item -> new Gson().toJson(item))
                .collect(toSet());
    }

    private ArrayList<Item> deserializeItems(Set<String> itemSet) {
        return (ArrayList<Item>) itemSet.stream()
                .map(item -> new Gson().fromJson(item, Item.class))
                .collect(toList());
    }
}